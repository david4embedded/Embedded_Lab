/*
 * Copyright (c) 2019 Nordic Semiconductor
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <zephyr/types.h>
#include <zephyr/sys/byteorder.h>
#include <zephyr/logging/log.h>
#include <zephyr/device.h>
#include <zephyr/drivers/spi.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/pm/device.h>
#include <zephyr/pm/device_runtime.h>

/* STEP 2.1 - Define the driver compatible from the custom binding */
#define DT_DRV_COMPAT zephyr_custom_bme280

LOG_MODULE_REGISTER(custom_bme280, CONFIG_SENSOR_LOG_LEVEL);

#define SPIOP	SPI_WORD_SET(8) | SPI_TRANSFER_MSB

/* STEP 2.2 - Check if the devicetree contains any devices with the driver compatible */
#if DT_NUM_INST_STATUS_OKAY(DT_DRV_COMPAT) == 0
#warning "Custom BME280 driver enabled without any devices"
#endif

/* STEP 3.1 - Define data structure to store BME280 data */
struct custom_bme280_data {
    uint8_t my_data;
};

/* STEP 3.2 - Define structure to store sensor configuration */
struct custom_bme280_config {
    struct spi_dt_spec spi;
};

static int custom_bme280_sample_fetch(const struct device *dev,
                      enum sensor_channel chan)
{
    __ASSERT_NO_MSG(chan == SENSOR_CHAN_ALL);

    LOG_INF("%s: sample_fetch: %d", dev->name, chan);
    return 0;
}

static int custom_bme280_channel_get(const struct device *dev,
                     enum sensor_channel chan,
                     struct sensor_value *val)
{
    LOG_INF("%s: channel_get: %d", dev->name, chan);

    switch (chan) {
    case SENSOR_CHAN_AMBIENT_TEMP:
        val->val1 = 1;
        val->val2 = 11;
        break;
    case SENSOR_CHAN_PRESS:
        val->val1 = 2;
        val->val2 = 22;
        break;
    case SENSOR_CHAN_HUMIDITY:
        val->val1 = 3;
        val->val2 = 33;
        break;
    default:
        return -ENOTSUP;
    }

    return 0;
}

/* STEP 3.3 - Define the sensor driver API */
static const struct sensor_driver_api custom_bme280_api = {
    .sample_fetch = &custom_bme280_sample_fetch,
    .channel_get = &custom_bme280_channel_get,
};

static int custom_bme280_init(const struct device *dev)
{
    LOG_INF("%s: init", dev->name);
    return 0;
}

static int custom_bme280_pm_action(const struct device *dev,
                                   enum pm_device_action action)
{
    int ret = 0;

    switch (action)
    {
    case PM_DEVICE_ACTION_RESUME:
        LOG_INF("%s: resume", dev->name);
        break;
    case PM_DEVICE_ACTION_SUSPEND:
        LOG_INF("%s: suspend", dev->name);
        break;
    default:
        return -ENOTSUP;
    }
    return ret;
}

/* STEP 5.1 - Define macro with device drivers structures */
#define CUSTOM_BME280_DEFINE(inst)                                              \
    static struct custom_bme280_data custom_bme280_data_##inst;                 \
    static const struct custom_bme280_config custom_bme280_config_##inst = {    \
        .spi = SPI_DT_SPEC_INST_GET(inst, SPIOP, 0),                            \
    };                                                                          \
    /* STEP 3.1 -  Attach power management fuction  */                          \
    PM_DEVICE_DT_INST_DEFINE(inst, custom_bme280_pm_action);                    \
    /* STEP 5.2 - Define a macro for the device driver instance */              \
    DEVICE_DT_INST_DEFINE(inst,                                                 \
                custom_bme280_init,                                             \
                NULL,                                                           \
                &custom_bme280_data_##inst,                                     \
                &custom_bme280_config_##inst,                                   \
                POST_KERNEL,                                                    \
                CONFIG_SENSOR_INIT_PRIORITY,                                    \
                &custom_bme280_api);

/* STEP 5.3 - Create the struct device for every status "okay" node in the devicetree */
DT_INST_FOREACH_STATUS_OKAY(CUSTOM_BME280_DEFINE)