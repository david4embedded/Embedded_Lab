/*
 * Copyright (c) 2016 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "Led.hpp"
#include "Button.hpp"
#include "Serial.hpp"

#include <zephyr/logging/log.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/kernel.h>
#include <zephyr/random/random.h>

#define SLEEP_TIME_MS  	(100)

// Device tree nodes
static const struct gpio_dt_spec s_gpioButton1 	= GPIO_DT_SPEC_GET(DT_ALIAS(sw0), gpios);

#define THREAD0_PRIORITY 4
#define THREAD1_PRIORITY 4

#define THREAD0_STACKSIZE 1024
#define THREAD1_STACKSIZE 1024

#define PRINTK(...) do {k_mutex_lock(&g_mutex, K_FOREVER); \
						printk(__VA_ARGS__); \
						k_mutex_unlock(&g_mutex); \
					} while(0)

static void thread0();
static void thread1();

K_THREAD_DEFINE(g_idThread0, THREAD0_STACKSIZE, thread0, nullptr, nullptr, nullptr, THREAD0_PRIORITY, 0,  5000);
K_THREAD_DEFINE(g_idThread1, THREAD1_STACKSIZE, thread1, nullptr, nullptr, nullptr, THREAD1_PRIORITY, 0,  5000);
K_MUTEX_DEFINE(g_mutex);
K_MSGQ_DEFINE(g_queue, sizeof(int), 10, 4);

bool g_runQueueTestThreads = false;
uint32_t g_thread0Counter = 0;
uint32_t g_thread1Counter = 0;

/**
 * @brief: The main function initializes the button and serial communication, then enters an infinite loop that checks the button state. 
 * @details: When the button is pressed, it sets g_runQueueTestThreads to true, allowing the two threads to run 
 */
int main(void)
{
	Button queueTestButton(s_gpioButton1);
	bool queueTestState = false;

	for(;;)
	{	
		bool state = queueTestButton.IsPressed();
		if(queueTestState != state) 
		{
			queueTestState = state;
			g_runQueueTestThreads = queueTestState;
		}
	
		k_msleep(SLEEP_TIME_MS);
	}
	return 0;
}

/**
 * @brief: A thread function that runs in an infinite loop, giving a message to the queue when g_runQueueTestThreads is true. 
 * @details: It uses the k_msgq_put function to put a message into the queue and the sys_rand32_get function to sleep for a random amount of time.
 */
void thread0(void)
{
	PRINTK("Thread 0 (Producer) started\n");

	int i = 0;

	for(;;)
	{
		if(!g_runQueueTestThreads) 
		{
			k_msleep(SLEEP_TIME_MS);
			continue;
		}

		int valueToSend = i++;
		k_msgq_put(&g_queue, &valueToSend, K_FOREVER);

		PRINTK("Producer gave a message, value=%d, counter=%d\n", valueToSend, ++g_thread0Counter);
		k_msleep(sys_rand32_get() % 10);
	}
}

/**
 * @brief: A thread function that runs in an infinite loop
 * @details: It uses the k_msgq_get function to get a message from the queue and the sys_rand32_get function to sleep for a random amount of time.
 */
void thread1(void)
{
	PRINTK("Thread 1 (Consumer) started\n");

	for(;;)
	{
		int valueReceived;
		k_msgq_get(&g_queue, &valueReceived, K_FOREVER);
		
		PRINTK("Consumer took a message, value=%d, counter=%d\n", valueReceived, ++g_thread1Counter);
		k_msleep(sys_rand32_get() % 10);
	}	
}
