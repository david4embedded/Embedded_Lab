* NOTE
  * This project is based off ../SungsuThreading whose git hash: ec8f6cbe46e1e09e0c3867c573d094a5348eba5c
  
* Steps to build through nRF Connect extension in VS Code
  1. Open this folder with VS Code.
  2. Clink on the nRF Connect extension.
  3. Add bulid configuration under `APPLICATIONS` menu on the left.
  4. Choose `nrf54l15dk/nrf54l10/cpuapp/ns` as the board target and the default settings for the others.
  5. Generate and build (It takes quite creating all the device tree stuffs).

* How to use
  1. Press button 1 to trigger running of thread0 and thread1 for the queue test.
  