/*
 * Copyright (c) 2016 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "Led.hpp"
#include "Button.hpp"
#include "Serial.hpp"

#include <zephyr/logging/log.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/kernel.h>
#include <zephyr/random/random.h>

#define SLEEP_TIME_MS  	(100)

// Device tree nodes
static const struct gpio_dt_spec s_gpioButton1 	= GPIO_DT_SPEC_GET(DT_ALIAS(sw0), gpios);
static const struct gpio_dt_spec s_gpioButton2 	= GPIO_DT_SPEC_GET(DT_ALIAS(sw1), gpios);

#define THREAD0_PRIORITY 4
#define THREAD1_PRIORITY 4
#define THREAD2_PRIORITY 4
#define THREAD3_PRIORITY 4

#define THREAD0_STACKSIZE 1024
#define THREAD1_STACKSIZE 1024
#define THREAD2_STACKSIZE 1024
#define THREAD3_STACKSIZE 1024

#define PRINTK(...) do {k_mutex_lock(&g_mutex, K_FOREVER); \
						printk(__VA_ARGS__); \
						k_mutex_unlock(&g_mutex); \
					} while(0)

static void thread0();
static void thread1();
static void thread2();
static void thread3();

K_THREAD_DEFINE(g_idThread0, THREAD0_STACKSIZE, thread0, nullptr, nullptr, nullptr, THREAD0_PRIORITY, 0,  5000);
K_THREAD_DEFINE(g_idThread1, THREAD1_STACKSIZE, thread1, nullptr, nullptr, nullptr, THREAD1_PRIORITY, 0,  5000);
K_THREAD_DEFINE(g_idThread2, THREAD2_STACKSIZE, thread2, nullptr, nullptr, nullptr, THREAD2_PRIORITY, 0,  5000);
K_THREAD_DEFINE(g_idThread3, THREAD3_STACKSIZE, thread3, nullptr, nullptr, nullptr, THREAD3_PRIORITY, 0,  5000);
K_MUTEX_DEFINE(g_mutex);
K_SEM_DEFINE(g_sem, 0, 10);

bool g_runMutexTestThreads = false;
bool g_runSemTestThreads = false;
uint32_t g_thread0Counter = 0;
uint32_t g_thread1Counter = 0;
uint32_t g_thread2Counter = 0;
uint32_t g_thread3Counter = 0;
uint32_t g_threadTotalCounter = 0; // only for thread0 and thread1

/**
 * @brief: The main function initializes the button and serial communication, then enters an infinite loop that checks the button state. 
 * @details: When the button is pressed, it sets g_runThreads to true, allowing the two threads to run 
 */
int main(void)
{
	Button mutexTestButton(s_gpioButton1);
	Button semTestButton(s_gpioButton2);

	bool mutexTestState = false;
	bool semTestState = false;

	for(;;)
	{	
		auto state = mutexTestButton.IsPressed();
		if(mutexTestState != state) 
		{
			mutexTestState = state;
			g_runMutexTestThreads = mutexTestState;
		}

		state = semTestButton.IsPressed();
		if(semTestState != state) 
		{
			semTestState = state;
			g_runSemTestThreads = semTestState;
		}
	
		k_msleep(SLEEP_TIME_MS);
	}
	return 0;
}

/**
 * @brief: A thread function that runs in an infinite loop, printing its counter values when g_runThreads is true. 
 * @details: It uses a mutex to synchronize access to the shared counter variables and the printk function.
 */
void thread0(void)
{
    PRINTK("Thread 0 started\n");

    for(;;)
	{
		if(!g_runMutexTestThreads) 
		{
			k_msleep(SLEEP_TIME_MS);
			continue;
		}

		++g_thread0Counter;
		PRINTK("Thread 0 is running, counter=%d/%d\n", g_thread0Counter, ++g_threadTotalCounter);
    }
}

/**
 * @brief: A thread function that runs in an infinite loop, printing its counter values when g_runThreads is true. 
 * @details: It uses a mutex to synchronize access to the shared counter variables and the printk function.
 */
void thread1(void)
{
	PRINTK("Thread 1 started\n");

    for(;;)
	{
		if(!g_runMutexTestThreads) 
		{
			k_msleep(SLEEP_TIME_MS);
			continue;
		}

		++g_thread1Counter;
		PRINTK("Thread 1 is running, counter=%d/%d\n", g_thread1Counter, ++g_threadTotalCounter);
    }
}

/**
 * @brief: A thread function that runs in an infinite loop, giving a semaphore when g_runSemTestThreads is true. 
 * @details: It uses the k_sem_give function to give a semaphore and the sys
 */
void thread2(void)
{
	PRINTK("Thread 2 (Producer) started\n");

	for(;;)
	{
		if(!g_runSemTestThreads) 
		{
			k_msleep(SLEEP_TIME_MS);
			continue;
		}

		k_sem_give(&g_sem);
		PRINTK("Producer gave a semaphore, counter=%d\n", ++g_thread2Counter);
		k_msleep(sys_rand32_get() % 10);
	}
}

/**
 * @brief: A thread function that runs in an infinite loop
 * @details: It uses the k_sem_take function to take a semaphore and the sys_rand32_get function to sleep for a random amount of time.
 */
void thread3(void)
{
	PRINTK("Thread 3 (Consumer) started\n");

	for(;;)
	{
		k_sem_take(&g_sem, K_FOREVER);
		PRINTK("Consumer took a semaphore, counter=%d\n", ++g_thread3Counter);
		k_msleep(sys_rand32_get() % 10);
	}	
}
